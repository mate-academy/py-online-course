import sys

if sys.version_info >= (3, 8):
    PY_GTE_38 = True
else:
    PY_GTE_38 = False

__version__ = "2.9.1"
