some_code = 2
this_should_not_be_checked = 1  # noqa
some_code = 3
